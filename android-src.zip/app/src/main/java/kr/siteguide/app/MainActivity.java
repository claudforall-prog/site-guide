package kr.siteguide.app;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Locale;

/* 앱 화면은 인터넷 주소에서 불러온다. 그래서 웹을 고치면 재설치 없이 내용이 바뀐다. */
public class MainActivity extends Activity {
    private static final String APP_URL = "https://claudforall-prog.github.io/site-guide/";
    private WebView web;
    private TextToSpeech tts;

    public class Voice {
        @JavascriptInterface public void speak(String text, String lang) {
            if (tts == null) return;
            tts.setLanguage(Locale.forLanguageTag(lang));
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "site-guide");
        }
        @JavascriptInterface public void stop() { if (tts != null) tts.stop(); }
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        tts = new TextToSpeech(this, status -> { });
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Voice(), "AndroidTTS");
        setContentView(web);
        if (state == null) web.loadUrl(APP_URL); else web.restoreState(state);
    }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }
    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (tts != null) tts.shutdown(); super.onDestroy(); }
}
